/// <reference types="chrome" />

import { pkiApi10, SignatureRequest, SignatureResponse, IdentifyRequest, IdentifyResponse, hexToString, stringToHex, encodeUint8ArrayToHex } from '@seal/common';

// import { SealError } from '@seal/common';

export class Seal {

    private static instance: Seal;

    private constructor() {

    }

    static isExtensionAvailable(): boolean {
        if (!chrome || !chrome.runtime) {
            // window.postMessage({ type: "extension-not-available" }, "*");
        }
        return true;
    }

    static getInstance(): Seal {
        if (!this.instance) {
            this.instance = new Seal();
        }
        return this.instance;
    }

    // @ts-ignore
    // private async sendMessage(request: SealRequest): Promise<SealResponse> {
    //     return new Promise((resolve, reject) => {
    //         chrome.runtime.sendMessage(request, (response: SealResponse) => {
    //             if (chrome.runtime.lastError) {
    //                 reject(new SealError(chrome.runtime.lastError.message || 'No information was provided.'));
    //                 return;
    //             }
    //
    //             if (response.status === "error") {
    //                 const errorResponse = response as ErrorResponse;
    //                 reject(new SealError(errorResponse.message || "No error information is available."));
    //                 return;
    //             }
    //             resolve(response);
    //         })
    //     });
    // }

    async sign(request: {
        subject?: string,
        buffer: Uint8Array
    }): Promise<SignatureResponse> {        
        if (!request) throw new TypeError("Missing required parameter: request");

        const { subject, buffer: bufferUint8Array } = request;

        if (!(bufferUint8Array instanceof Uint8Array)) {
            throw new TypeError("request.buffer must be a Uint8Array");
        }

        return pkiApi10.sendMessage('sign', {
            ...(subject && { subject }),
            buffer: encodeUint8ArrayToHex(bufferUint8Array)
        }, location.origin)
            .then(response => {
                console.log("sign response: " + JSON.stringify(response));
                // response.chain = response.chain.map(value => stringToHex(value));
                response.signature = hexToString(response.signature);
                response.signer = hexToString(response.signer);
                return response;
            });
    }

    async identify(request: IdentifyRequest): Promise<IdentifyResponse> {
        return pkiApi10.sendMessage('identify', request, location.origin)
            .then(response => {
                response.signer = hexToString(response.signer);
                response.chain = response.chain.map(value => hexToString(value));
                return response;
            });
    }

    // async verify(data: any) {
    //     const request: SealRequest = {
    //         tabId: "currentTab",
    //         requestId: `${Date.now()}`,
    //         command: "verify",
    //         data,
    //     };
    //
    //     const response = await this.sendMessage(request);
    //     return response;
    // }
    //
    // async validate(data: any) {
    //     const request: SealRequest = {
    //         tabId: "currentTab",
    //         requestId: `${Date.now()}`,
    //         command: 'validate',
    //         data,
    //     };
    //
    //     const response = await this.sendMessage(request);
    //     return response;
    // }

}