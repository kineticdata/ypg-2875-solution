/// <reference types="chrome" />

import { pkiApi10, extensionApi10, SignatureResponse, IdentifyRequest, IdentifyResponse, hexToString, encodeUint8ArrayToHex } from '@seal/common';

/**
 * Signs the provided data using the specified parameters.
 *
 * @param {Object} request - The signing request object.
 * @param {string} [request.subject] - The subject associated with the signature process (optional).
 * @param {Uint8Array} request.buffer - The data to be signed as a Uint8Array.
 * @return {Promise<SignatureResponse>} A promise that resolves to the signature response containing the signature and signer information.
 * @throws {TypeError} If the request is missing or the buffer is not a Uint8Array.
 */
export async function sign(request: {
    subject?: string,
    buffer: Uint8Array
}): Promise<SignatureResponse> {
    if (!request) throw new TypeError("Missing required parameter: request");

    const { subject, buffer: bufferUint8Array } = request;

    if (!(bufferUint8Array instanceof Uint8Array)) {
        throw new TypeError("request.buffer must be a Uint8Array");
    }

    return pkiApi10.sendMessage('sign', {
        ...(subject && { subject }),
        buffer: encodeUint8ArrayToHex(bufferUint8Array)
    }, location.origin)
        .then(response => {
            console.log("sign response: " + JSON.stringify(response));
            response.signature = hexToString(response.signature);
            response.signer = hexToString(response.signer);
            return response;
        });
}

/**
 * Sends an identify request to the PKI API and processes the response.
 *
 * @param {IdentifyRequest} request - The request object containing identification data.
 * @return {Promise<IdentifyResponse>} A promise that resolves to the processed identification response.
 */
export async function identify(request: IdentifyRequest): Promise<IdentifyResponse> {
    return pkiApi10.sendMessage('identify', request, location.origin)
        .then(response => {
            response.signer = hexToString(response.signer);
            response.chain = response.chain.map(value => hexToString(value));
            return response;
        });
}

/**
 * Retrieves the API version of the extension backend.
 *
 * @return {Promise<string>} A promise that resolves to a string representing the API version.
 */
export async function getApiVersion(): Promise<string> {
    return extensionApi10.sendMessage('getApiVersion', undefined, location.origin);
}

/**
 * Retrieves the extension version.
 *
 * @return {Promise<string>} A promise that resolves to a string representing the extension version.
 */
export async function getVersion(): Promise<string> {
    return extensionApi10.sendMessage('getVersion', undefined, location.origin);
}